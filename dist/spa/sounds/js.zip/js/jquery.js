  $(document).ready(function(){  


$(function() {

   var tree;     


  $.ajax({
            type: "GET",
            url: APP_URL + '/treeview',
            data: {
                   format: 'json'
                  },
            success: function(data) {
              
                tree =  $('#treeview3').treeview({
                                 levels: 99,
                                 data: data,
                                 showCheckbox: true,

                                 onNodeSelected: function(event, node) {
                          
                                     }
                           });


                
                },
             error: function() {
                  alert('ERROR: falla al intertar obtener treeview ');
            }
        });

  


  $.ajax({
            type: "GET",
            url: APP_URL + '/nuevoGrupo',
            data: {
                   format: 'json'
                  },
            success: function(data) {
              
                $('#test').html(JSON.stringify(data));


                
                },
             error: function() {
                  alert('ERROR: falla al intertar obtener treeview ');
            }
        });
  

        
  });

$('#btn-select-node.select-node').on('click', function (e) {
         alert('t');
        });

});
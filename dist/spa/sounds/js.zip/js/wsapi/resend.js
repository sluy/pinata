if (!window.wsapi) {
  window.wsapi = {};
}

window.wsapi.resend = {
  service: null,
  onSuccess: null,
  onError: null,
  cfg: {},
  modal: {
    template: `<div class="modal centered fade" tabindex="-1" role="dialog" id="wsapi-resend-modal">
              <div class="modal-dialog centered" role="document" style="max-width:300px">
                <div class="modal-content">
                  <div class="modal-header">
                    <h4 class="modal-title">Whatsapp no enviado</h4>
                  </div>
                  <div class="modal-body">
                    <h5>El mensaje de WhatsApp no fue enviado</h5>
                    <p>Esto puede deberse a: </p>
                    <ul>
                        <li>El n&uacute;mero de WhatsApp es incorrecto.</li>
                        <li>No posee WhatsApp correctamente vinculado.</li>
                    </ul>
                  </div>
                  <div class="modal-footer">
                    <div style="text-align:center;">
                        <button type="button" id="wsapi-resend-modal-action-make" class="btn btn-default wsapi-resend-modal-action break-xs">
                            <span id="wsapi-resend-modal-loader" class="hide">
    							<small style="opacity:0;"></small>
    							<i class="fa fa-spinner fa-spin" style="font-size:18px; margin: -3px;"></i>
    						</span>
                            Reenviar
                        </button>
                        <button type="button" id="wsapi-resend-modal-action-manual" class="btn btn-default wsapi-resend-modal-action break-xs">Enviar manualmente</button>
                        
                    </div>
                  </div>
                </div>
              </div>
            </div>`,
    create: function () {
      return new Promise(function (resolve) {
        console.log("Agregando modal?");
        if ($("#wsapi-resend-modal").length) {
          console.log("No");
          resolve();
          return;
        }
        $("body").append(window.wsapi.resend.modal.template);
        setTimeout(function () {
          $("#wsapi-resend-modal-action-rebind").click(function (e) {
            e.preventDefault();
            e.stopPropagation();
            window.wsapi.resend.rebind();
          });
          $("#wsapi-resend-modal-action-manual").click(function (e) {
            e.preventDefault();
            e.stopPropagation();
            window.wsapi.resend.manual();
          });
          $("#wsapi-resend-modal-action-make").click(function (e) {
            e.preventDefault();
            e.stopPropagation();
            window.wsapi.resend.make();
          });
          console.log("Modal agregado");
          resolve();
        }, 100);
      });
    },
    open: function (id, cfg) {
      return new Promise(function () {
        window.wsapi.resend.modal.create().then(function () {
          setTimeout(function () {
            window.wsapi.resend.service = parseInt(id);
            window.wsapi.resend.cfg = typeof cfg === 'object' && cfg !== null ? cfg : {};
            console.log("Mostrando el modal para el servicio", id, window.wsapi.resend.cfg);
            $('#wsapi-resend-modal .modal-header').css('display', window.wsapi.resend.cfg.hideHeader === true ? 'none' : 'block');
            $('#wsapi-resend-modal .modal-body').css('display', window.wsapi.resend.cfg.hideBody === true ? 'none' : 'block');
            $('#wsapi-resend-modal .modal-footer').css('display', window.wsapi.resend.cfg.hideFooter === true ? 'none' : 'block');
            $("#wsapi-resend-modal").modal("show");
          }, 100);
        });
      });
    },
    close: function () {
      return new Promise(function () {
        window.wsapi.resend.modal.create().then(function () {
          setTimeout(function () {
            window.wsapi.resend.service = null;
            $("#wsapi-resend-modal").modal("hide");
          }, 100);
        });
      });
    },
  },
  rebind: function () {
    return new Promise(function (resolve) {
      resolve();
      window.location.replace("./?ruta=wsapi/rebind");
    });
  },
  manual: function () {
    return new Promise(function (resolve) {
      console.log("Enviar manualmente", window.wsapi.resend.service, window.wsapi.resend.cfg);
      if (typeof window.wsapi.resend.cfg.onManual === 'function') {
        window.wsapi.resend.cfg.onManual();
      }
      if (typeof window.wsapi.resend.cfg.onSuccess === 'function') {
          window.wsapi.resend.cfg.onSuccess();
      }
      resolve();
    });
  },
  make: function () {
    return new Promise(function (resolve) {
      $(".wsapi-resend-modal-action").attr("disabled", "disabled");
      $("#wsapi-resend-modal-loader").removeClass("hide");
      const url = window.location.protocol + "//" + window.location.host + '/?ruta=servicios/resend_wp_message&servicio=' + window.wsapi.resend.service;
      console.log("Reenviar datos del servicio", url);
      
      $.ajax({
        type: "GET",
        url: url,
        cache: false,
        contentType: false,
        processData: false,
        success: function (result, status) {
          console.log('success', result, status);
          $(".wsapi-resend-modal-action").removeAttr("disabled");
          $("#wsapi-resend-modal-loader").addClass("hide");
          if (
            status === "success" &&
            typeof result === "object" &&
            result !== null &&
            result.status === "sended"
          ) {
            console.log('Ok', window.wsapi.resend.cfg);
            if (typeof window.wsapi.resend.cfg.onSuccess === "function") {
              window.wsapi.resend.cfg.onSuccess(result);
            }
            window.wsapi.resend.modal.close();
            resolve();
          }
        },
        error: function (err) {
          console.log('success', error);
          $(".wsapi-resend-modal-action").removeAttr("disabled");
          $("#wsapi-resend-modal-loader").addClass("hide");

          if (typeof window.wsapi.resend.cfg.onError === "function") {
            window.wsapi.resend.cfg.onError(err);
          }
          resolve();
        },
      });
    });
  },
};


function showWsApiChatActions () {
    $('.wsapi-chat-actions').css('display', 'block');   
}

function hideWsApiChatActions () {
    $('.wsapi-chat-actions').css('display', 'none');
}

function openWsApiGlobalChat (url, typo) {
    console.log('openning global', url);
    const $chat = $('#wsapi-chat-window');
    //Si no está el control en html, o la instancia es inválida
    if (!$chat.length) {
        return false;
    }
    
    if (typo === 'global') {
        $chat.removeClass('service-chat');
    } else {
        $chat.addClass('service-chat');
    }
    
    
    //Mostramos la ventana.
    $chat.css('display', 'block');
    showWsApiChatActions();
    document.body.style.overflow = 'hidden'
    window.scrollTo(0,0);
    resizeWsApiChat();
    url += '&user=0';
    url += '&rand=' + Math.random().toString(36).slice(2);
    console.log('Abriendo', url);
    
    $chat.html(`<iframe src="${url}" frameborder="0" height="100%" width="100%" scrolling="no"></iframe>`);
}

window.openWsApiChat = function (instance, phone) {
    instance = parseInt(instance);
    phone = typeof phone === 'string' ? phone.replace(/\D/g,'') : '';
    const $chat = $('#wsapi-chat-window');
    //Si no está el control en html, o la instancia es inválida
    if (!$chat.length || isNaN(instance) || instance < 0) {
        return false;
    }
    //Mostramos la ventana.
    $chat.css('display', 'block');
    
    if (phone === '') {
        console.log('NO TIENE TLF , ES CHAT GLOBAL');
        $chat.removeClass('service-chat');
    } else {
        console.log('TIENE TLF , ES CHAT DE SERVICIO');
        $chat.addClass('service-chat');
    }
    
    showWsApiChatActions();
    document.body.style.overflow = 'hidden'
    window.scrollTo(0,0);
    //url del iframe...
    let url = `https://chat.neo.fo/?instance=${instance}`;
    //Si hay teléfono, construimos con la opción "dense" (para mostrar sólo la ventana de chat)
    if (phone !== '') {
        url += `&chat=${phone}&dense=true`;
    }
    resizeWsApiChat();
    $chat.html(`<iframe src="${url}" frameborder="0" height="100%" width="100%"></iframe>`);
}

function resizeWsApiChat() {
    var isMini = $('body').hasClass('mini-width'); 
    var sidebarOpen = $('body').hasClass('sidebar-open');
    var isCollapse = $('body').hasClass('sidebar-collapse');
    const $chat = $('#wsapi-chat-window');
    let width = window.innnerWidth;
    let height = window.innerHeight;
    
    let woff = 0;
    let hoff = 0;
    
    
    const $sidebar = document.getElementsByClassName('main-sidebar');
    if ($sidebar && $sidebar[0]) {
        const rect = $sidebar[0].getBoundingClientRect();
        woff = rect.width;
    }
    const $topbar = document.getElementsByClassName('navbar-static-top');
    if ($topbar && $topbar[0]) {
        const rect = $topbar[0].getBoundingClientRect();
        hoff = rect.height;
    }
    
    if (isMini) {
        woff = (isCollapse) ? -30 : 0;
        hoff = '100';
    }
    console.log('[sidebar]Es mini?', isMini);
    console.log('[sidebar]Sidebar open?', sidebarOpen);
    console.log('[sidebar]Es collapse?', isCollapse);
    console.log('[sidebar]',woff, hoff);
    console.log('[sidebar]###############');
    
    console.warn('TOP', hoff);
    
    $chat.css('top', (hoff) ? `${hoff}px` : '0');
    
    if ($(window).width < 768) {
        $chat.css('left', (woff) ? `${woff}px` : '0');
    } else {
        $chat.css('left', null);
    }
    
    $chat.width('width', width + 'px');
    $chat.height('height', height + 'px');
}

function closeWsApiChat()  {
    document.body.style.overflow = 'auto';
    const $chat = $('#wsapi-chat-window');
    if ($chat) {
        $chat.css('display', 'none');
        hideWsApiChatActions();
        return true;
    }
    hideWsApiChatActions();
    return false;
}

$(function () {
    $('*').click(function (e) {
        closeWsApiChat();
    });
    
    $('.btn-open-wsapi-chat').click(function(e) {
       e.preventDefault();
       e.stopPropagation();
       openWsApiGlobalChat($(this).attr('href'), 'service');
    });
    $('.wsapi-chat-global-trigger').click(function(e) {
        e.preventDefault();
        e.stopPropagation();
        openWsApiGlobalChat($(this).attr('href'), 'global');
    });
    
    $('.wsapi-chat-actions .close').click(function() {
       closeWsApiChat(); 
    });

    $('.sidebar-toggle').on('click', async function() {
        let count = 0;
        if(!$('#wsapi-chat-window').length) {
            
        }
        while(count <= 100) {
            await new Promise(function(resolve)  {
                setTimeout(function () {
                    resizeWsApiChat();
                    resolve();
                }, 5)    
            });
            count++;
        }
    });
    $('window').on('resize', function() {
        console.log('[sidebar] resize triggered');
        resizeWsApiChat();
    });
});